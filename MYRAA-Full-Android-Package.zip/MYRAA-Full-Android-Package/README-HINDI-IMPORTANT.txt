MYRAA — Full Source + Android Starter Package

WHAT IS INCLUDED
1. MYRAA-Original.html — the HTML file supplied by the user.
2. MYRAA-Original-Source-Code-1.5.2.zip — the untouched original source archive.
3. MYRAA-Android-Project/ — the Android Studio WebView project, mobile HTML, and the extracted original source tree (266 files).

IMPORTANT: This is a source package, NOT a verified APK.
The supplied source is a Windows desktop application built with web/Node/Electron/Python components. Those source files are preserved in original-source/; simply putting them inside one HTML file cannot make the desktop features run on Android. Windows-only capabilities (desktop control, Electron overlay/tray, Windows screen capture, and the Windows/Python agent) need a separate Android implementation and permissions. Gemini/API-backed features also need their compatible backend/configuration.

BUILD
Open MYRAA-Android-Project/ in Android Studio, allow Gradle sync, then use Build > Build APK(s).
Alternatively, the project contains a GitHub Actions workflow under .github/workflows/ if present in the copied project. The APK build has not been compiled or tested in this environment, so build errors may need fixing.

Do not put private API keys into the HTML or a public repository.
