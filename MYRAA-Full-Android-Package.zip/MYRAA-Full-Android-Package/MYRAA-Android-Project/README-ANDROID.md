# MYRAA Android project (mobile port starter)

This package combines the supplied `MYRAA (2).html` interface with the complete supplied MYRAA 1.5.2 source tree and an Android Studio WebView shell. It is prepared for Android testing; it is **not a prebuilt APK**.

## What is included
- `app/src/main/assets/index.html`: your HTML app, with mobile viewport/touch adjustments.
- Android Studio project (`app/`, Gradle files): app shell, file picker support (including `.pmx`/`.zip` imports), and WebView microphone permission handling.
- PWA files: `manifest.webmanifest`, `sw.js`, `icon.svg`.
- `original-source/`: the source ZIP extracted into normal folders, unchanged in content.
- `MYRAA-Android.html` is also provided separately alongside this ZIP.

## Build an APK on Android Studio
1. Copy this folder to a computer with Android Studio installed.
2. Open this folder in Android Studio and let Gradle sync (internet is required the first time).
3. Choose **Build > Build APK(s)**.
4. Android Studio will show the APK path, normally `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have Android SDK/Gradle configured, so I could not compile and test an APK here.

## Important feature limits on Android
The original source describes a **Windows desktop** app. Its Gemini Live bridge, encrypted Windows DPAPI key storage, Electron desktop overlay/tray, Windows screen capture, and Windows app/file control depend on its Node backend, Electron, and Windows/Python desktop agent. Copying those files into an Android WebView does not make those capabilities work on a phone. They are preserved in `original-source/` but are not falsely advertised as active in this mobile wrapper.

The provided HTML already includes a character studio/import interface and browser voice features. Actual voice recognition/speech support depends on Android System WebView/browser support and permissions. The HTML interface has no Gemini API integration in its own code; do not paste a private API key into the HTML. To enable Gemini on Android safely, a separate authenticated backend/mobile-specific integration is still needed.

## PWA option
For the installable browser version, host the project root over HTTPS (or localhost during development), then open it in Chrome on Android and use **Add to Home screen / Install app**. Opening the HTML directly from the Files app will not enable service workers/PWA offline installation.

## Security & privacy
- Microphone access is requested by Android when the page asks for it.
- Screen viewing and desktop control are not enabled by this wrapper.
- Do not put API keys or passwords into client-side HTML or public source files.
